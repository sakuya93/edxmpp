<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
</head>
<body>

<div id="live_class_information_window" class="modal fade bd-example-modal-xl" tabindex="-1">
    <div class="modal-dialog modal-xl" role="document" id="dialog">
        <div class="modal-content" id="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="live_class_information_Title">開始上課</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" id="live_class_information_area">
            </div>
            <div class="modal-footer">
                <button id="class_status_confirm" type="button" class="btn btn-primary">確認</button>
                <button type="button" id="match_time_close" class="btn btn-secondary" data-dismiss="modal">關閉</button>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<?php
