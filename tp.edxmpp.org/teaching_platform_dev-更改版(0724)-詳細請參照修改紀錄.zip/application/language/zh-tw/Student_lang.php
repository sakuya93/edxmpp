<?php
$lang['view'] = array(
  ''
);