<html>
　<head>
    　<title>TEAMS崁入測試</title>
      <meta http-equiv="X-Frame-Options" content="deny">
    　</head>
　<body>
<iframe src="https://teams.microsoft.com/_#/pre-join-calling/19:meeting_ZmMwNWU4M2QtOGViMC00MzE1LThjNjUtZjg4YTY1NDA2YmQ3@thread.v2"></iframe>
</body>

</html>
